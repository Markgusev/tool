import os
import struct
import zlib
import itertools as it
from pathlib import Path, PurePath
from Crypto.Cipher import AES
from Crypto.Cipher.AES import MODE_CBC
from Crypto.Hash import SHA1
from Crypto.Util.Padding import pad
import gmalg
from zstandard import ZstdCompressor, ZstdDecompressor, ZstdCompressionDict, DICT_TYPE_AUTO
import const
from sm4_variant import SM4

# Import your existing unpacker classes
from n import TencentPakFile, TencentPakEntry, Reader

class PakRepacker:
    def __init__(self, base_path):
        self.base_path = Path(base_path)
        self.edited_path = self.base_path / "EDITED"
        self.original_path = self.base_path / "ORIGINAL"
        self.output_path = self.base_path / "OUTPUT"
        
        # Create directories if they don't exist
        self.edited_path.mkdir(parents=True, exist_ok=True)
        self.original_path.mkdir(parents=True, exist_ok=True)
        self.output_path.mkdir(parents=True, exist_ok=True)
        
        self.pak_files = []
        self.selected_pak = None
        self.pak_parser = None

    def scan_pak_files(self):
        """Scan for .pak files in ORIGINAL directory"""
        self.pak_files = list(self.original_path.glob("*.pak"))
        return self.pak_files

    def parse_original_pak(self, pak_file):
        """Parse the original PAK to get file information"""
        print(f"📂 Parsing original PAK structure...")
        try:
            # Use your existing unpacker to parse the PAK
            self.pak_parser = TencentPakFile(pak_file, is_od=True)
            print(f"✅ PAK parsed successfully")
            print(f"📊 Found {len(self.pak_parser._index)} directories with {sum(len(files) for files in self.pak_parser._index.values())} files")
            return True
        except Exception as e:
            print(f"❌ Error parsing PAK: {e}")
            return False

    def get_original_file_info(self, file_path):
        """Get original file information from PAK"""
        rel_path_str = str(file_path)
        
        print(f"🔍 Searching for: {rel_path_str}")
        
        # Search for the file in the PAK index
        for dir_path, files_dict in self.pak_parser._index.items():
            for filename, entry in files_dict.items():
                full_path = dir_path / filename
                if str(full_path) == rel_path_str:
                    print(f"✅ Found exact match: {full_path}")
                    return {
                        'entry': entry,
                        'encryption_method': entry.encryption_method,
                        'compression_method': entry.compression_method,
                        'original_size': entry.size,  # Compressed+encrypted size in PAK
                        'uncompressed_size': entry.uncompressed_size,
                        'offset': entry.offset
                    }
        
        # If not found, try filename match
        for dir_path, files_dict in self.pak_parser._index.items():
            for filename, entry in files_dict.items():
                if filename == file_path.name:
                    print(f"✅ Found filename match: {dir_path / filename}")
                    return {
                        'entry': entry,
                        'encryption_method': entry.encryption_method,
                        'compression_method': entry.compression_method,
                        'original_size': entry.size,
                        'uncompressed_size': entry.uncompressed_size,
                        'offset': entry.offset
                    }
        
        print(f"❌ File not found in PAK: {rel_path_str}")
        return None

    def compress_data_to_fit(self, data, target_size, compression_method):
        """Compress data to fit within target size with multiple attempts"""
        print(f"    🎯 Target size: {target_size:,} bytes")
        print(f"    📦 Our data: {len(data):,} bytes (uncompressed)")
        
        if compression_method == 1:  # ZLIB
            print("    🗜️ Trying compression strategies:")
            
            best_size = len(data)
            best_data = data
            best_method = "No compression"
            
            # Try different compression levels
            for level, desc in [(9, "Max"), (6, "Default"), (1, "Fast")]:
                compressed = zlib.compress(data, level)
                status = "✅ FITS!" if len(compressed) <= target_size else "❌ Too big"
                print(f"      Level {level} ({desc}): {len(compressed):,} bytes - {status}")
                
                if len(compressed) <= target_size and len(compressed) < best_size:
                    best_size = len(compressed)
                    best_data = compressed
                    best_method = f"Level {level}"
            
            # Try without compression
            no_compress_status = "✅ FITS!" if len(data) <= target_size else "❌ Too big"
            print(f"      No compression: {len(data):,} bytes - {no_compress_status}")
            
            if len(data) <= target_size and len(data) < best_size:
                best_size = len(data)
                best_data = data
                best_method = "No compression"
            
            print(f"    🏆 Best method: {best_method} - {best_size:,} bytes")
            
            if best_size > target_size:
                print(f"    ⚠️  All methods too large. Need to reduce file size by {best_size - target_size:,} bytes")
                # Ask user if they want to force truncate
                choice = input("    🤔 Force truncate anyway? (y/n): ").strip().lower()
                if choice == 'y':
                    print(f"    ⚠️  Truncating from {best_size:,} to {target_size:,} bytes")
                    return best_data[:target_size]
                else:
                    return None
            
            return best_data
        
        elif compression_method == 0:  # No compression
            if len(data) <= target_size:
                print(f"    ✅ No compression needed: {len(data):,} bytes")
                return data
            else:
                print(f"    ❌ File too large: {len(data):,} > {target_size:,} bytes")
                choice = input("    🤔 Force truncate anyway? (y/n): ").strip().lower()
                if choice == 'y':
                    return data[:target_size]
                else:
                    return None
        
        else:
            print(f"    ❓ Unknown compression method: {compression_method}")
            return data

    def encrypt_data(self, data, encryption_method, file_path):
        """Encrypt data using specified method"""
        if encryption_method == const.EM_SIMPLE1:
            return bytes(x ^ const.SIMPLE1_DECRYPT_KEY for x in data)
        elif encryption_method == const.EM_SIMPLE2:
            return self._encrypt_simple2(data)
        elif encryption_method & const.EM_SM4_NEW_MASK != 0:
            return self._encrypt_sm4(data, file_path, encryption_method)
        else:
            return data

    def _encrypt_simple2(self, data):
        """Encrypt using SIMPLE2 method"""
        class RollingKey:
            def __init__(self, initial_value: int):
                self._value = initial_value

            def update(self, x: int) -> int:
                self._value ^= x
                return self._value

        aligned_size = ((len(data) + const.SIMPLE2_BLOCK_SIZE - 1) // const.SIMPLE2_BLOCK_SIZE) * const.SIMPLE2_BLOCK_SIZE
        if len(data) < aligned_size:
            data = data + b'\x00' * (aligned_size - len(data))

        initial_key, = struct.unpack('<I', const.SIMPLE2_DECRYPT_KEY)
        rolling_key = RollingKey(initial_key)
        
        ciphertext = bytearray()
        for i in range(0, len(data), 4):
            chunk = data[i:i+4]
            if len(chunk) < 4:
                chunk = chunk + b'\x00' * (4 - len(chunk))
            plain_int = struct.unpack('<I', chunk)[0]
            cipher_int = rolling_key.update(plain_int)
            ciphertext.extend(struct.pack('<I', cipher_int))
        
        return bytes(ciphertext)

    def _encrypt_sm4(self, data, file_path, encryption_method):
        """Encrypt using SM4 method"""
        block_size = SM4.block_length()
        aligned_size = ((len(data) + block_size - 1) // block_size) * block_size
        if len(data) < aligned_size:
            data = data + b'\x00' * (aligned_size - len(data))

        key = self._derive_sm4_key(file_path, encryption_method)
        sm4 = SM4(key)
        
        ciphertext = bytearray()
        for i in range(0, len(data), block_size):
            block = data[i:i+block_size]
            encrypted_block = sm4.encrypt(block)
            ciphertext.extend(encrypted_block)
        
        return bytes(ciphertext)

    def _derive_sm4_key(self, file_path, encryption_method):
        """Derive SM4 key"""
        part1 = PurePath(file_path).stem.lower()
        if encryption_method == const.EM_SM4_2:
            secret = const.SM4_SECRET_2
        elif encryption_method == const.EM_SM4_4:
            secret = const.SM4_SECRET_4
        else:
            index = (encryption_method - const.EM_SM4_NEW_BASE) % len(const.SM4_SECRET_NEW)
            secret = f'{const.SM4_SECRET_NEW[index]}{encryption_method}'
        return SHA1.new(str(part1 + secret).encode()).digest()[:SM4.key_length()]

    def prepare_file_replacements(self):
        """Prepare files from EDITED folder for replacement using ACTUAL PAK data"""
        file_replacements = {}
        
        print("\n📦 Preparing files for replacement...")
        
        for edited_file in self.edited_path.rglob("*"):
            if edited_file.is_file():
                # Read the modified file
                with open(edited_file, 'rb') as f:
                    file_data = f.read()
                
                # Get relative path (must match path in original PAK)
                rel_path = edited_file.relative_to(self.edited_path)
                
                print(f"\n🔧 Processing: {rel_path}")
                print(f"    📄 File size: {len(file_data):,} bytes")
                
                # Get ACTUAL file info from original PAK
                original_info = self.get_original_file_info(rel_path)
                
                if not original_info:
                    print(f"    ❌ Skipping - file not found in original PAK")
                    continue
                
                print(f"    📊 Original PAK info:")
                print(f"      - Size in PAK: {original_info['original_size']:,} bytes")
                print(f"      - Uncompressed: {original_info['uncompressed_size']:,} bytes") 
                print(f"      - Encryption: {original_info['encryption_method']}")
                print(f"      - Compression: {original_info['compression_method']}")
                print(f"      - Offset: 0x{original_info['offset']:X}")
                
                # Use ACTUAL target size from original PAK
                target_compressed_size = original_info['original_size']
                
                # Compress to match target size
                compressed_data = self.compress_data_to_fit(file_data, target_compressed_size, original_info['compression_method'])
                
                if compressed_data is None:
                    print(f"    ❌ Compression failed - file too large")
                    continue
                
                print(f"    ✅ Final compressed size: {len(compressed_data):,} bytes")
                
                # Encrypt the data
                encrypted_data = self.encrypt_data(compressed_data, original_info['encryption_method'], edited_file)
                print(f"    🔐 Encrypted size: {len(encrypted_data):,} bytes")
                
                # Check final size
                if len(encrypted_data) > target_compressed_size:
                    print(f"    ⚠️  WARNING: Encrypted data larger than target!")
                    print(f"    ⚠️  {len(encrypted_data):,} > {target_compressed_size:,} bytes")
                    choice = input("    🤔 Continue anyway? (y/n): ").strip().lower()
                    if choice != 'y':
                        continue
                    # Truncate to fit
                    encrypted_data = encrypted_data[:target_compressed_size]
                    print(f"    ⚠️  Truncated to: {len(encrypted_data):,} bytes")
                
                # Store replacement info
                file_replacements[str(rel_path)] = {
                    'encrypted_data': encrypted_data,
                    'uncompressed_size': len(file_data),
                    'compressed_size': len(compressed_data),
                    'encrypted_size': len(encrypted_data),
                    'encryption_method': original_info['encryption_method'],
                    'compression_method': original_info['compression_method'],
                    'target_size': target_compressed_size,
                    'original_offset': original_info['offset'],
                    'original_entry': original_info['entry']
                }
                
                print(f"    ✅ Successfully prepared for replacement")
        
        return file_replacements

    def replace_files_in_pak(self, original_pak_path, file_replacements, output_name):
        """Replace files in original PAK while maintaining exact same structure and size"""
        print("\n🔄 Replacing files in original PAK...")
        
        try:
            # Read original PAK
            with open(original_pak_path, 'rb') as f:
                original_data = bytearray(f.read())
            
            original_size = len(original_data)
            print(f"📊 Original PAK size: {original_size:,} bytes")
            
            modifications = 0
            
            for rel_path, replacement_info in file_replacements.items():
                print(f"\n🔧 Replacing: {rel_path}")
                
                # Use ACTUAL offset and size from original PAK
                file_offset = replacement_info['original_offset']
                file_size = replacement_info['target_size']
                
                print(f"    📍 Offset in PAK: 0x{file_offset:X}")
                print(f"    🎯 Target size: {file_size:,} bytes")
                print(f"    📦 Our data size: {len(replacement_info['encrypted_data']):,} bytes")
                
                # Ensure our replacement data fits
                if len(replacement_info['encrypted_data']) <= file_size:
                    # Pad if necessary to maintain exact size
                    padded_data = replacement_info['encrypted_data']
                    if len(padded_data) < file_size:
                        padding = file_size - len(padded_data)
                        padded_data += b'\x00' * padding
                        print(f"    📏 Added {padding:,} bytes padding to match original size")
                    
                    # ACTUALLY REPLACE THE DATA in the PAK
                    original_data[file_offset:file_offset+file_size] = padded_data
                    modifications += 1
                    print(f"    ✅ Successfully replaced")
                else:
                    print(f"    ❌ ERROR: Replacement data too large!")
                    print(f"    ❌ {len(replacement_info['encrypted_data']):,} > {file_size:,} bytes")
                    # Force replace with truncation
                    truncated_data = replacement_info['encrypted_data'][:file_size]
                    original_data[file_offset:file_offset+file_size] = truncated_data
                    modifications += 1
                    print(f"    ⚠️  Forced replacement with truncation")
            
            # Write modified PAK
            output_file = self.output_path / output_name
            with open(output_file, 'wb') as f:
                f.write(original_data)
            
            new_size = os.path.getsize(output_file)
            
            print(f"\n📊 REPACK SUMMARY:")
            print("=" * 50)
            print(f"✅ Modified PAK: {output_file.name}")
            print(f"✅ Original size: {original_size:,} bytes")
            print(f"✅ New size: {new_size:,} bytes")
            print(f"✅ Size maintained: {original_size == new_size}")
            print(f"✅ Files successfully replaced: {modifications}/{len(file_replacements)}")
            
            if original_size != new_size:
                print("⚠️  WARNING: File size changed! This may cause issues.")
            
            return True
            
        except Exception as e:
            print(f"❌ Error replacing files in PAK: {e}")
            import traceback
            traceback.print_exc()
            return False

    def repack_pak(self, output_name):
        """Main repacking function - REPLACE files in original PAK"""
        if not self.selected_pak:
            print("No PAK file selected!")
            return False

        print(f"🎯 Replacing files in {self.selected_pak.name}...")
        
        try:
            # First, parse the original PAK to get file information
            if not self.parse_original_pak(self.selected_pak):
                print("Failed to parse original PAK!")
                return False
            
            # Prepare file replacements using ACTUAL PAK data
            file_replacements = self.prepare_file_replacements()
            
            if not file_replacements:
                print("❌ No files prepared for replacement!")
                return False
            
            print(f"\n📋 Ready to replace {len(file_replacements)} files:")
            for file_path in file_replacements.keys():
                print(f"   - {file_path}")
            
            # Replace files in original PAK
            success = self.replace_files_in_pak(self.selected_pak, file_replacements, output_name)
            
            return success
            
        except Exception as e:
            print(f"❌ Error during repacking: {e}")
            import traceback
            traceback.print_exc()
            return False

    def show_menu(self):
        """Display the main menu"""
        while True:
            print("\n" + "="*50)
            print("           REPACK TOOL - IN-PLACE REPLACEMENT")
            print("="*50)
            print("1. REPLACE FILES IN PAK")
            print("2. DEBUG FILE SIZES")
            print("3. EXIT")
            print("="*50)
            
            choice = input("Select option (1-3): ").strip()
            
            if choice == "1":
                self.repack_menu()
            elif choice == "2":
                self.debug_file_sizes()
            elif choice == "3":
                print("Goodbye!")
                break
            else:
                print("Invalid option! Please try again.")

    def debug_file_sizes(self):
        """Debug function to check file sizes in PAK"""
        print("\n" + "="*50)
        print("DEBUG FILE SIZES")
        print("="*50)
        
        pak_files = self.scan_pak_files()
        if not pak_files:
            print("No PAK files found!")
            return
        
        print("Available PAK files:")
        for i, pak_file in enumerate(pak_files, 1):
            print(f"{i}. {pak_file.name}")
        
        try:
            choice = int(input(f"\nSelect PAK file to debug (1-{len(pak_files)}): "))
            if 1 <= choice <= len(pak_files):
                pak_file = pak_files[choice - 1]
                self._debug_pak_contents(pak_file)
            else:
                print("Invalid selection!")
        except ValueError:
            print("Please enter a valid number!")

    def _debug_pak_contents(self, pak_file):
        """Debug contents of a specific PAK file"""
        print(f"\n🔍 Analyzing: {pak_file.name}")
        try:
            pak = TencentPakFile(pak_file, is_od=True)
            
            # Check for files in EDITED folder
            edited_files = list(self.edited_path.rglob("*"))
            edited_files = [f for f in edited_files if f.is_file()]
            
            if edited_files:
                print(f"\n📂 Files in EDITED folder:")
                for edited_file in edited_files:
                    rel_path = edited_file.relative_to(self.edited_path)
                    print(f"   - {rel_path}")
                    
                    # Try to find this file in PAK
                    found = False
                    for dir_path, files_dict in pak._index.items():
                        for filename, entry in files_dict.items():
                            full_path = dir_path / filename
                            if str(full_path) == str(rel_path) or filename == rel_path.name:
                                print(f"     📍 Found in PAK:")
                                print(f"        Offset: 0x{entry.offset:X}")
                                print(f"        Size: {entry.size:,} bytes")
                                print(f"        Uncompressed: {entry.uncompressed_size:,} bytes")
                                print(f"        Compression: {entry.compression_method}")
                                print(f"        Encryption: {entry.encryption_method}")
                                found = True
                                break
                        if found:
                            break
                    
                    if not found:
                        print(f"     ❌ NOT FOUND in PAK")
            
            else:
                print("No files in EDITED folder to check")
                
        except Exception as e:
            print(f"Error: {e}")

    def repack_menu(self):
        """Display repacking menu"""
        print("\nScanning for PAK files...")
        pak_files = self.scan_pak_files()
        
        if not pak_files:
            print("No .pak files found in ORIGINAL folder!")
            print(f"Please place your original .pak files in: {self.original_path}")
            return
        
        print("\nAvailable PAK files:")
        for i, pak_file in enumerate(pak_files, 1):
            print(f"{i}. {pak_file.name}")
        print(f"{len(pak_files) + 1}. Back to main menu")
        
        try:
            choice = int(input(f"\nSelect PAK file to modify (1-{len(pak_files) + 1}): "))
            if choice == len(pak_files) + 1:
                return
            elif 1 <= choice <= len(pak_files):
                selected_pak = pak_files[choice - 1]
                self.selected_pak = selected_pak
                self.process_repack(selected_pak)
            else:
                print("Invalid selection!")
        except ValueError:
            print("Please enter a valid number!")

    def process_repack(self, pak_file):
        """Process the repacking operation"""
        print(f"\n🎯 Replacing files in: {pak_file.name}")
        
        # Check if EDITED folder has files
        edited_files = list(self.edited_path.rglob("*"))
        edited_files = [f for f in edited_files if f.is_file()]
        
        if not edited_files:
            print("No files found in EDITED folder!")
            print(f"Please place your replacement files in: {self.edited_path}")
            print("IMPORTANT: Files must have the same paths and names as in the original PAK!")
            return
        
        print(f"Found {len(edited_files)} files to replace:")
        for file in edited_files:
            print(f"  - {file.relative_to(self.edited_path)}")
        
        # Get output filename
        default_name = f"modified_{pak_file.name}"
        output_name = input(f"\nEnter output filename [{default_name}]: ").strip()
        if not output_name:
            output_name = default_name
        
        # Important warning
        print("\n⚠️  IMPORTANT: This will maintain the EXACT SAME file size as original.")
        print("   The script will try multiple compression methods to make files fit.")
        
        confirm = input(f"\nReplace {len(edited_files)} files in {pak_file.name}? (y/n): ").strip().lower()
        if confirm in ['y', 'yes']:
            success = self.repack_pak(output_name)
            if success:
                print("🎉 Files replaced in PAK successfully!")
                print("📍 Output folder: /storage/emulated/0/Download/Repack/OUTPUT/")
            else:
                print("💥 Failed to replace files in PAK!")
        else:
            print("Operation cancelled.")

def main():
    # Set the base directory
    base_directory = "/storage/emulated/0/Download/Repack"
    
    # Check if directory exists
    if not Path(base_directory).exists():
        print(f"Directory does not exist: {base_directory}")
        print("Please create the directory or update the path.")
        return
    
    # Initialize and run the repacker
    repacker = PakRepacker(base_directory)
    repacker.show_menu()

if __name__ == "__main__":
    main()