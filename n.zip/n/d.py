# debug_sizes.py
import sys
from pathlib import Path

# Add the path to your unpacker script
sys.path.append('/storage/emulated/0/Download/Repack')

# Import your unpacker classes
from n import TencentPakFile  # Change 'n' to your actual unpacker script name

def check_original_file_sizes():
    """Check what sizes files actually are in the original PAK"""
    pak_file_path = "/storage/emulated/0/Download/Repack/ORIGINAL/game_patch_4.0.0.20329.pak"
    
    print("🔍 Analyzing original PAK file sizes...")
    print(f"PAK file: {pak_file_path}")
    
    try:
        # Use your unpacker to parse the PAK
        pak = TencentPakFile(pak_file_path, is_od=True)
        
        # Look for your file
        target_file = "WeaponAvatarBattleEffect.uasset"
        found_files = []
        
        print(f"\n📂 Searching for: {target_file}")
        print("=" * 50)
        
        for dir_path, files_dict in pak._index.items():
            for filename, entry in files_dict.items():
                full_path = str(dir_path / filename)
                if target_file.lower() in filename.lower() or target_file.lower() in full_path.lower():
                    found_files.append((full_path, entry))
        
        if found_files:
            for file_path, entry in found_files:
                print(f"📁 Found: {file_path}")
                print(f"   📦 Size in PAK: {entry.size:,} bytes")
                print(f"   🗜️  Uncompressed: {entry.uncompressed_size:,} bytes")
                print(f"   🔐 Encrypted: {entry.encrypted}")
                print(f"   🔒 Encryption Method: {entry.encryption_method}")
                print(f"   🗜️  Compression Method: {entry.compression_method}")
                print(f"   📍 Offset in PAK: 0x{entry.offset:X}")
                print("-" * 30)
        else:
            print(f"❌ File '{target_file}' not found in PAK")
            print("\n📂 Available files (first 20):")
            count = 0
            for dir_path, files_dict in pak._index.items():
                for filename, entry in files_dict.items():
                    if count < 20:
                        print(f"   - {dir_path / filename}")
                        count += 1
                    else:
                        break
                if count >= 20:
                    break
            
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    check_original_file_sizes()